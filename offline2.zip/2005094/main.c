#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>
#include "utils.h"

Image *read_PPM(char *filename)
{
    /* opens a PPM file, constructs an Image object and returns a pointer to it.
    Use fopen(), fscanf(), fprintf(), and fclose().*/


    FILE *fp;
    fp=fopen("DennisRitchie.ppm","r");

    char s[50];
    int n,i,j;
    Image *image=(Image*)malloc(sizeof(Image));
    Color pxl;
    fscanf(fp,"%s",&s);
    fscanf(fp,"%d %d",&image->cols,&image->rows);
    fscanf(fp,"%d",&n);
    image->image=(Color**)malloc(sizeof(Color*)*image->rows);
    for(i=0; i<image->rows; i++)
    {
        image->image[i]=(Color*)malloc(sizeof(Color)*image->cols);
    }
    for(i=0; i<image->rows; i++)
    {
        for(j=0; j<image->cols; j++)
        {
            fscanf(fp,"%d %d %d",&pxl.R,&pxl.G,&pxl.B);

            image->image[i][j]=pxl;

        }
    }
    fclose(fp);
    return image;
}

void write_PPM(Image *image, char *filename)
{
    /* takes an Image object and writes to filename in PPM format.*/
    FILE *fp2;
    int i,j;
    Color pxl;
    fp2=fopen("secret_image.ppm","w");
    fprintf(fp2,"P3\n");
    fprintf(fp2,"%d %d \n",image->cols,image->rows);
    fprintf(fp2,"255 \n");
    for(i=0; i<image->rows; i++)
    {

        for(j=0; j<image->cols; j++)
        {

            fprintf(fp2,"%d %d %d  ",image->image[i][j].R,image->image[i][j].G,image->image[i][j].B);

        }
        fprintf(fp2,"\n");


    }
    fclose(fp2);


}

void free_image(Image *image)
{
    /* takes an Image object and frees all the memory associated with it.
    This involves not only calling free on image but also on the appropriate
    members of it. */

    free(image->image);
    image->image=NULL;
    free(image);
    image=NULL;

}


Color *evaluate_one_pixel(Image *image, int row, int col)
{
    /* Takes an Image object and returns what color the pixel at the given row/col
    should be in the secret image. This function should not change image*/
    Color pixel;
    pixel.R=image->image[row][col].R;
    pixel.G=image->image[row][col].G;
    pixel.B=image->image[row][col].B;
    return pixel.B;

}

Image *get_secret_image(Image *image)
{
    /* takes an Image object, and constructs the secret image from it by extracting
    the LSB of the B channel. You should call evaluate_one_pixel() here. */

    int i,j,n;


    for(i=0; i<image->rows; i++)
    {

        for(j=0; j<image->cols; j++)
        {
            n=evaluate_one_pixel(image,i,j);
            if(n%2==0)
            {

                image->image[i][j].R=0;
                image->image[i][j].G=0;
                image->image[i][j].B=0;
            }
            else
            {

                image->image[i][j].R=255;
                image->image[i][j].G=255;
                image->image[i][j].B=255;

            }
        }
    }

    return image;
}

int main()
{
    Image* img=read_PPM("DennisRitchie.ppm");
    Image* img2=get_secret_image(img);
    write_PPM(img2,"secret_image.ppm");
    free_image(img);

    return 0;
}


